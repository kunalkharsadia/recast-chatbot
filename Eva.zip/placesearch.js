const axios = require('axios');




function placesearch(cuisine, results) {
	var replies = {
                    'replies': []
                };

				var content = {
                    'content': []
                };
    var url = "https://developers.zomato.com/api/v2.1/search?apikey=3237b193d6a2b5f0f778c31083f59b35&q=" + cuisine + "&city_id=" + results;
    console.log(url)
    return axios.get(url)
        .then(response => {
            results = response.data.restaurants
            if (results.length === 0) {
                return [{
                    type: 'quickReplies',

                    content: {
                        title: 'Sorry, but I could not find any results for your request :(',

                        buttons: [{
                            title: 'Start over',
                            value: 'Start over'
                        }],
                    },
                }]
            }

            console.log(results[0].restaurant.name);

            /* const cards = results.slice(0, 10).map(restaurant => ({
                title: "restaurant.name",
                subtitle: "restaurant.cuisines",
                imageUrl: "https://b.zmtcdn.com/data/pictures/chains/1/43601/394dc95ee95ded26ca6460bc09d5d167.jpg",
                buttons: [{
                    type: 'web_url',
                    value: "restaurant.url",
                    title: 'View More',
                }, ],
            })); */
			for(var i=0;i<results.length;i++){
				content['content'].push({
					title: results[i].restaurant.name,
					subtitle:  results[i].restaurant.name,
					imageUrl:  results[i].restaurant.featured_image,
					buttons: [
					{
					type: 'web_url',
					value: results[i].restaurant.url,
					title: 'Visit Website',
					},
				]
            });
				
			}
			

          /*   return [{
                    type: 'text',
                    content: "Here's what I found for you!",
                },
                {
                    type: 'carousel',
                    content: cards
                },
            ]; */
			console.log(content);
			   replies['replies'].push({
				 "type": "carousel",
					"content":content.content
			});
			
			console.log(replies.replies);
			return replies.replies;

        });
}

module.exports = placesearch;