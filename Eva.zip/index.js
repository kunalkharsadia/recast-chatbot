const express = require('express');
const bodyParser = require('body-parser');
const config = require('./config.js');
const placesearch = require('./placesearch.js');
const axios = require('axios');

const app = express();

app.use(bodyParser.json());


app.post('/errors', (req, res) => {
	console.error(req.body);
	
	res.sendStatus(200);
	
});

// Reastaurant Search

app.post('/restaurant-area',(req, res) => {
	
	
	  const place = req.body.nlp.entities.location[0].raw;
	  console.log(place);
	  const cuisine = req.body.nlp.entities.cuisine[0].raw;
	  console.log(cuisine);
	  
	  var url="https://developers.zomato.com/api/v2.1/cities?apikey=3237b193d6a2b5f0f778c31083f59b35&q="+place;
		axios.get(url)
		.then(response => {
			results = response.data.location_suggestions;
			console.log(results[0].id);
			
   
  return placesearch(cuisine, results[0].id)
    .then((carousel) => res.json({
     replies: carousel,
    }))
    .catch((err) => console.error(' error: ', err));
	
	
})});

app.listen(config.PORT, () => console.log(`App started on port ${config.PORT}`));